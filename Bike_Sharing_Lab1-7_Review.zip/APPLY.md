# Хэрэглэх заавар

Энэ ZIP-ийг BIke-sharing-app репогийн үндсэн хавтсанд задлаад өөрчлөлтийг шалгана.
`Lab2`, `Lab3`, `Lab4` эх файлуудыг энэ багц солихгүй.

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-dev.txt
.venv/bin/python -m pytest -q
git add .gitignore .github requirements-dev.txt Lab5.1 Lab7 docs
git commit -m "Review Lab 1–7, refine UML and add Python CI"
git push origin <өөрийн-branch>
```

GitHub холболтын write эрх 403 өгсөн учраас энэ багц remote репод тавигдаагүй.
Lab 1–4, 6–7-ийн үлдсэн нотолгоог `docs/lab1-7-audit.md`-аас шалгана.
Lab 7-ийн ногоон/улаан Actions run, screenshot-ийг бодит push-ийн дараа хавсаргана.
