# Лаборатори 7 — GitHub Actions CI

Репогийн үндсэн `.github/workflows/ci.yml` нь `push` болон `pull_request` бүрд
checkout, Python тохиргоо, хамаарал суулгалт, тест гэсэн дөрвөн алхам ажиллуулна.
Python 3.12, Flask болон pytest-ийн хувилбарууд `requirements-dev.txt`-д байна.

## Локал шалгалт

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-dev.txt
.venv/bin/python -m pytest -q
```

2026-11-02-ны хяналтын орчинд: **28 тест болон 26 subtest амжилттай**.
Энэ нь GitHub Actions-ийн амжилттай run-ыг орлохгүй.

## Удирдамжийн нотолгоог гүйцээх

1. Workflow-той branch-ийг GitHub руу push хийж, Actions дахь ногоон run-ийн холбоос,
   screenshot, commit SHA-г хавсаргах.
2. Тусдаа туршилтын branch дээр нэг тестийн хүлээгдэж буй үр дүнг түр эвдэж push хийн,
   улаан run-ийн холбоос, screenshot, алдааны мөрийг хадгалах.
3. Тестийг буцааж зассан commit push хийн дахин ногоон болсныг батлах.

**Төлөв:** workflow бэлтгэгдсэн, локал тест амжилттай. GitHub дахь ногоон/улаан
run, хоёр screenshot одоогоор нотлогдоогүй тул Lab 7-г бүрэн болсон гэж үзэхгүй.
